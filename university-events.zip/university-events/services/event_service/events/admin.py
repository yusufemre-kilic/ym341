﻿from django.contrib import admin
from .models import Event

@admin.register(Event)
class EventAdmin(admin.ModelAdmin):
    list_display = ('title', 'teacher_keycloak_id', 'date', 'is_approved', 'created_at')
    list_filter = ('is_approved',)
    actions = ['approve_events']

    def approve_events(self, request, queryset):
        queryset.update(is_approved=True)
    approve_events.short_description = "Seçilen etkinlikleri onay durumu: EVET olarak ayarla"
