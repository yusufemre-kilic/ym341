﻿from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status
from .models import Event
from django.views.decorators.csrf import csrf_exempt
import json

@csrf_exempt
@api_view(['POST'])
def create_event(request):
    if request.method == 'POST':
        teacher_id = request.headers.get('X-Sub') 
        
        if not teacher_id:
            return Response({'detail': 'Yetkilendirme bilgisi eksik (X-Sub).'}, status=status.HTTP_401_UNAUTHORIZED)

        try:
            data = json.loads(request.body.decode('utf-8'))
        except json.JSONDecodeError:
            return Response({'detail': 'Geçersiz JSON formatı.'}, status=status.HTTP_400_BAD_REQUEST)

        title = data.get('title')
        description = data.get('description')
        
        if not title or not description:
            return Response({'detail': 'Başlık (title) ve Açıklama (description) alanları zorunludur.'}, status=status.HTTP_400_BAD_REQUEST)
        
        event = Event.objects.create(
            teacher_keycloak_id=teacher_id,
            title=title,
            description=description,
        )
        
        return Response({
            'id': event.id,
            'title': event.title,
            'is_approved': event.is_approved
        }, status=status.HTTP_201_CREATED)
