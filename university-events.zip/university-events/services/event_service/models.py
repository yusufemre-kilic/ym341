from django.db import models
from django.utils import timezone

class Event(models.Model):
    # Keycloak'tan gelen öğretmen ID'si
    teacher_keycloak_id = models.CharField(max_length=255)
    
    title = models.CharField(max_length=200)
    description = models.TextField()
    date = models.DateTimeField(default=timezone.now)
    is_approved = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.title