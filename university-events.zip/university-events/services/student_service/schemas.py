﻿from pydantic import BaseModel
from datetime import datetime
from typing import Optional

class StudentRegister(BaseModel):
    first_name: str
    last_name: str
    department: Optional[str] = None 

class StudentResponse(BaseModel):
    keycloak_id: str
    email: str
    first_name: str
    last_name: str
    registered_at: datetime

    class Config:
        orm_mode = True
