﻿from fastapi import FastAPI, Header, HTTPException, Depends, status
from sqlalchemy.orm import Session
from . import models, schemas
from .database import engine, get_db
from datetime import datetime

models.Base.metadata.create_all(bind=engine)

app = FastAPI()

# KAYIT ENDPOINT'İ
@app.post("/v1/register", response_model=schemas.StudentResponse)
def register_student(
    student_data: schemas.StudentRegister,
    db: Session = Depends(get_db),
    x_sub: str = Header(..., description="Keycloak User ID"),
    x_email: str = Header(..., description="Keycloak User Email")
):
    db_student = db.query(models.Student).filter(models.Student.keycloak_id == x_sub).first()
    if db_student:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Bu öğrenci zaten kayıtlı.")

    new_student = models.Student(
        keycloak_id=x_sub,
        email=x_email,
        first_name=student_data.first_name,
        last_name=student_data.last_name,
        registered_at=datetime.utcnow()
    )
    
    db.add(new_student)
    db.commit()
    db.refresh(new_student)
    return new_student

# PROFİL ENDPOINT'İ
@app.get("/v1/me", response_model=schemas.StudentResponse)
async def get_my_info(db: Session = Depends(get_db), x_sub: str = Header(...)):
    db_student = db.query(models.Student).filter(models.Student.keycloak_id == x_sub).first()
    
    if not db_student:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Öğrenci kaydı bulunamadı. Lütfen önce kayıt olun."
        )
        
    return db_student
